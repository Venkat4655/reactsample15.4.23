# ej2-react-grids-filtering

React Filtering sample with menu filtering type.

## Installing

To install all dependent packages, use the below command

```
npm install
```

## Run sample

To run the sample, use the below command

```
npm start
```